Zdravím tady tvůrce kamaráda. Jsem rád že jsi si stáhl můj program z GitHubu. Prosím postupuj podle tohoto readme.

----------
Instalace:

Prosím extrahuj tento program ze složky Kamarád.zip

----------
Editor databáze:

Stačí pouze zmáčknout možnost na příslušný editor.

----------
Komunikace:

Bohužel tato komunikace je pouze beta. Pro vypnutí komunikace na tvrdo vypněte program.

----------
Problém? Kontaktujte mě na: Koudelka.tomas.35@gmail.com

C0deM8n (c) 2024